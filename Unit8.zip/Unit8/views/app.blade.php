<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sam's Library</title>
</head>
<h1>Sam's Dank Books</h1>
<hr/>
<body>
<div class="container">
    @yield('content')
</div>

@yield('footer')
</body>
</html>